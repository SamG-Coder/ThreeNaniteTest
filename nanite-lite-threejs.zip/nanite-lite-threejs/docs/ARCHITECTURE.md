# Architecture

## Design target

The project targets the useful middle ground between normal Three.js LOD objects and a full virtualized-geometry renderer.

The renderer is GPU-driven after asset construction. JavaScript updates camera uniforms and submits a fixed sequence of compute and render passes. It does not inspect individual instances, LODs or meshlets every frame.

## 1. Asset representation

### Shared vertex streams

Every generated LOD references the original source vertices. The GPU receives:

```text
vertices          vec4<f32>
normals           vec4<f32>
uvs               vec2<f32>
```

The fourth position and normal components are padding suitable for storage-buffer alignment and matrix multiplication.

### Fixed meshlet index stream

Every cluster occupies exactly:

```text
64 triangles × 3 indices = 192 uint32 values
```

Clusters containing fewer triangles are padded with degenerate triangles. Therefore the source index for a vertex invocation is:

```text
clusterId * 192 + localVertex
```

This removes a metadata read from the vertex path and lets one non-indexed indirect draw expand every accepted meshlet.

### Cluster culling data

Each cluster stores three four-component records:

```text
bounds      centre.xyz, radius
cone apex   apex.xyz, cutoff
cone axis   axis.xyz, unused
```

The build also stores one integer LOD ID per cluster for the debug view.

### LOD table

Each LOD table entry contains:

```text
geometric error
first cluster
cluster count
original triangle count
```

The table is a small uniform array and can be indexed dynamically by the selected LOD.

## 2. Per-frame compute

### Counter clear

A small compute pass clears:

- Visible meshlet count
- Overflow flag
- Per-LOD accepted meshlet counters

### Instance culling and LOD selection

One compute invocation handles one instance.

It creates a deterministic uniform-scale world matrix, writes that matrix into a storage buffer and tests the instance bounding sphere against all six frustum planes.

When HZB culling is valid, the same sphere is tested against the previous frame's depth pyramid.

LOD selection uses projected geometric error:

```text
pixelError = geometricError × scale × cot(fov / 2) × screenHeight
             -----------------------------------------------------
                           2 × distanceToSurface
```

The coarsest LOD below the UI threshold is selected.

### Cluster culling

The invocation loops over clusters in the selected LOD and performs:

1. Bounding-sphere frustum culling
2. Meshlet normal-cone culling
3. Previous-frame HZB sphere culling
4. Atomic append into the visible list

The current prototype follows the same simple per-instance loop shape used by Three.js's compute-rasterizer research example. A more scalable hierarchy should replace it with queue traversal and one invocation per node or cluster.

### Visible list

Each accepted item is only two integers:

```text
instanceId
clusterId
```

The atomic counter is allowed to continue increasing after the storage capacity is reached, but writes are guarded. The indirect draw count is clamped and a separate overflow flag is set.

### Draw arguments

A one-invocation compute pass writes:

```text
vertexCount   = min(visibleMeshlets, capacity) × 192
instanceCount = 1
firstVertex   = 0
firstInstance = 0
```

The resulting `IndirectStorageBufferAttribute` is attached directly to the dummy `BufferGeometry`.

## 3. Vertex pulling

The hardware vertex stage receives only `vertexIndex` from the draw.

It calculates:

```text
visibleSlot = vertexIndex / 192
localVertex = vertexIndex % 192
```

Then it reads:

```text
visibleList[visibleSlot]
indexBuffer[clusterId * 192 + localVertex]
vertexBuffer[sourceVertex]
normalBuffer[sourceVertex]
uvBuffer[sourceVertex]
instanceWorld[instanceId]
```

World position, normal, UV, instance ID, cluster ID and LOD ID are passed to the selected node material.

## 4. HZB occlusion

The Nanite Lite scene and ordinary Three.js occluders render into an HDR render target with a float depth texture.

After rendering, compute kernels build a maximum-depth pyramid. Level zero is half resolution. Every subsequent level keeps the maximum of a 2×2 block from the previous level.

The next frame projects the closest point of a bounding sphere into the previous view and selects a pyramid level based on the sphere's projected footprint. A sphere is rejected when its nearest depth is farther than the maximum stored depth plus a bias.

The history is disabled when:

- The renderer has no prior frame
- The viewport changes
- Occluder visibility changes
- Camera translation or rotation is treated as a cut

This reduces catastrophic false occlusion, but a production implementation should add a second current-frame re-test pass for previously occluded nodes.

## 5. Normal-cone culling

Meshoptimizer calculates a cone containing the directions of all triangles in a meshlet. The compute pass transforms the cone axis and apex into world space.

A cluster is rejected when:

```text
dot(normalize(worldApex - cameraPosition), worldAxis) >= coneCutoff
```

That means every triangle in the cluster is guaranteed to be back-facing.

## 6. Debugging

The demo reads the visible count, overflow flag and LOD counters back to the CPU approximately twice per second.

Readback is diagnostic and deliberately asynchronous. A failure does not stop rendering.

Debug materials show:

- Hashed meshlet and instance IDs
- Selected cluster LOD
- World-space normals
