# Three.js WebGPU Nanite Lite

A runnable GPU-driven geometry prototype for **Three.js 0.185.1** and WebGPU.

This is not Unreal Engine Nanite. It implements a deliberately smaller and understandable subset that is useful in a browser renderer:

- Meshoptimizer-generated discrete LODs
- 64-vertex / 64-triangle meshlets
- Per-instance and per-meshlet GPU frustum culling
- Meshlet normal-cone backface culling
- Screen-space geometric-error LOD selection
- Previous-frame hierarchical-Z occlusion culling
- GPU-compacted visible meshlet list
- GPU-generated indirect draw arguments
- Storage-buffer vertex pulling
- One hardware-rasterized draw for the Nanite Lite geometry
- Live GPU readback statistics and LOD distribution
- Runtime `.glb` import for the largest static mesh

The project starts with a procedural torus knot containing 65,536 source triangles. It places 196 instances in the scene, representing roughly 12.8 million source triangles before visibility and LOD selection.

## Run it

Requirements:

- Node.js 22.12 or newer
- A current Chrome or Edge build with WebGPU enabled

```bash
npm install
npm run dev
```

Then open the address printed by Vite, normally `http://localhost:5173`.

Production build:

```bash
npm run build
npm run preview
```

Static syntax validation:

```bash
npm run validate
```

## Controls

- Left drag: orbit
- Mouse wheel: zoom
- Right drag: pan
- **Output**: shaded, meshlet IDs, selected LOD, or world normals
- **LOD error**: acceptable projected geometric error in pixels
- **Previous-frame HZB occlusion**: enable or disable GPU occlusion rejection
- **Meshlet normal-cone culling**: reject clusters whose triangles all face away
- **Show test occluders**: display or hide the wall used to exercise HZB culling
- **Load .glb**: use the largest non-skinned static mesh in a binary glTF

## Source layout

```text
src/
  main.js                    Application bootstrap, camera and GLB loading
  buildNaniteLiteAsset.js    Mesh simplification, meshlet generation and packing
  NaniteLiteRenderer.js      GPU buffers, compute culling, HZB and indirect draw
  config.js                  Meshlet, LOD and scene limits
  ui.js                      Controls and GPU readback display
  styles.css                 Demo interface

docs/
  ARCHITECTURE.md            Pipeline and data-flow explanation
  ROADMAP.md                 Path from this prototype to a fuller Nanite system
```

## What the prototype actually does

### Asset build

`buildNaniteLiteAsset()` performs the following work in the browser:

1. Copies an indexed triangle mesh into tightly defined position, normal and UV arrays.
2. Creates six index-only LODs with Meshoptimizer's attribute-aware simplifier.
3. Splits every LOD into 64/64 meshlets.
4. Calculates a bounding sphere and normal cone for every meshlet.
5. Pads every meshlet to exactly 64 triangle slots with degenerate triangles.
6. Packs all LOD meshlets into shared GPU storage buffers.

The simplifier keeps references to the original vertices, so every LOD shares one vertex, normal and UV stream. Only the meshlet index streams and bounds differ.

### GPU frame

Each frame executes:

```text
clear counters
    ↓
GPU instance culling
    ↓
screen-space LOD selection
    ↓
GPU meshlet frustum / cone / HZB culling
    ↓
compact visible meshlets with atomic append
    ↓
write non-indexed indirect draw arguments
    ↓
vertex-pulled hardware rasterization
    ↓
build current depth pyramid for the next frame
    ↓
present the HDR render target
```

The draw shader derives a visible-list slot and local meshlet vertex directly from `vertexIndex`:

```text
visibleSlot = vertexIndex / 192
localVertex = vertexIndex % 192
```

It then reads `(instanceId, clusterId)` from the compacted visible list, pulls the cluster's real source index and vertex attributes from storage buffers, applies the GPU-generated instance transform and passes the result into a Three.js node material.

## Important limits

This prototype is intentionally honest about what it does not implement:

- It uses a **discrete whole-object LOD chain**, not a crack-free hierarchical cluster DAG.
- All generated geometry is fully resident in GPU memory.
- It does not stream geometry pages.
- It uses hardware rasterization only; there is no specialised compute path for sub-pixel triangles.
- A single procedural material is applied to Nanite Lite geometry.
- The GLB loader selects one static mesh and ignores additional primitives and material assignments.
- Skinned meshes, morph targets, transparency, transmission and runtime vertex displacement are unsupported.
- Instance transforms use uniform scaling, allowing normals and culling bounds to use the same world matrix safely.
- Occlusion uses the previous frame and is invalidated after camera cuts, viewport changes or occluder visibility changes. It is still a research-grade implementation, not a production two-pass occlusion system.
- The fixed visible-list capacity is 16,384 meshlets. The UI displays an overflow warning when it is exceeded.

## Memory note

The indirect draw expands a visible meshlet into 192 vertex invocations. Three.js uses a dummy position attribute to establish a WebGPU-valid vertex range even though the shader pulls real positions from storage buffers. The dummy attribute uses an unused `float32x3` element, matching Three.js' normal position-buffer contract. At the default 16,384-meshlet capacity, it is approximately 36 MiB.

Reduce `MAX_VISIBLE_CLUSTERS` in `src/config.js` for lower-memory devices. Increase it only after profiling.

## Why the renderer uses 64/64 meshlets

A 64-triangle meshlet maps cleanly to a 64-thread compute workgroup and gives predictable fixed-size expansion for the indirect draw. It is not universally optimal, but it is a reasonable cross-vendor starting point for WebGPU.

## Moving toward a real hierarchy

The next architectural step is not another distance LOD. It is replacing the six object LODs with a cluster hierarchy:

1. Build leaf meshlets.
2. Partition topologically and spatially adjacent meshlets into groups.
3. Simplify each group while locking the external boundary.
4. Re-cluster the simplified parent representation.
5. Repeat until a small root representation remains.
6. Traverse nodes on the GPU with ping-pong queues.
7. Render a resident parent when requested child pages are unavailable.

See [`docs/ROADMAP.md`](docs/ROADMAP.md).

## Credits

The implementation is built on:

- [Three.js](https://threejs.org/) WebGPU renderer and TSL
- [meshoptimizer](https://github.com/zeux/meshoptimizer) simplification and meshlet algorithms, exposed through the Three.js add-on modules

Both dependencies are installed through npm and retain their own licences.
